/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.client.sms.controller;

/**
 *
 * @author Balaji
 */

import java.util.Arrays;
import java.util.Base64;
import java.util.List;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.client.sms.entity.Staff;

@Controller 
@RequestMapping("/staff")
public class StaffController {
    public StaffController() {

	}
	

@GetMapping("/list")
	public String listEmployees(Model theModel) {
		
		RestTemplate restTemplate = new RestTemplate();
    	String plainCreds = "john:test123";
    	byte[] plainCredsBytes = plainCreds.getBytes();
    	byte[] base64CredsBytes = Base64.getEncoder().encode(plainCredsBytes);
    	String base64Creds = new String(base64CredsBytes);
    	HttpHeaders headers = new HttpHeaders();
    	headers.add("Authorization", "Basic " + base64Creds);
    	String fooResourceUrl = "http://localhost:8080/api/staff";
    	
    	HttpEntity<String> request = new HttpEntity<String>(headers);
    	ResponseEntity<Staff[]> response = restTemplate.exchange(fooResourceUrl, HttpMethod.GET, request, Staff[].class);
    	Staff[] foo = response.getBody();
    	
    	List<Staff> theSemesters = Arrays.asList(foo);
    	theModel.addAttribute("Staff", theSemesters);
		
		return "list-staff";
	}
}



