package com.client.sms.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Semester1 {

	

	private int id;
	private int businessIntelligence;
	private int dataAnalytics;
	private int projectManagementAgility;
	private int advancedProgrammingJava;
	private int researchWorkshop;
	private int french;

	public Semester1() {
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getBusinessIntelligence() {
		return businessIntelligence;
	}

	public void setBusinessIntelligence(int businessIntelligence) {
		this.businessIntelligence = businessIntelligence;
	}

	public int getDataAnalytics() {
		return dataAnalytics;
	}

	public void setDataAnalytics(int dataAnalytics) {
		this.dataAnalytics = dataAnalytics;
	}

	public int getProjectManagementAgility() {
		return projectManagementAgility;
	}

	public void setProjectManagementAgility(int projectManagementAgility) {
		this.projectManagementAgility = projectManagementAgility;
	}

	public int getAdvancedProgrammingJava() {
		return advancedProgrammingJava;
	}

	public void setAdvancedProgrammingJava(int advancedProgrammingJava) {
		this.advancedProgrammingJava = advancedProgrammingJava;
	}

	public int getResearchWorkshop() {
		return researchWorkshop;
	}

	public void setResearchWorkshop(int researchWorkshop) {
		this.researchWorkshop = researchWorkshop;
	}

	public int getFrench() {
		return french;
	}

	public void setFrench(int french) {
		this.french = french;
	}


	@Override
	public String toString() {
		return "Semester1 [id=" + id + ", businessIntelligence=" + businessIntelligence + ", dataAnalytics="
				+ dataAnalytics + ", projectManagementAgility=" + projectManagementAgility
				+ ", advancedProgrammingJava=" + advancedProgrammingJava + ", researchWorkshop=" + researchWorkshop
				+ ", french=" + french + "]";
	}
	
	
	
}
