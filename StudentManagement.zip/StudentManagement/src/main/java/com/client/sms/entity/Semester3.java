/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.client.sms.entity;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Semester3 {


	private int id;
	private int innovationSoftwareMethods;
	private int innovationDataManagement;
	private int cyberSecurity;
	private int internetOfThings;
	private int collectiveIntelligence;
        private int strategyInnovation;
	private int french; 
	  
	 

	public Semester3() {
		
	}

	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public int getInnovationSoftwareMethods() {
		return innovationSoftwareMethods;
	}



	public void setInnovationSoftwareMethods(int innovationSoftwareMethods) {
		this.innovationSoftwareMethods = innovationSoftwareMethods;
	}



	public int getInnovationDataManagement() {
		return innovationDataManagement;
	}



	public void setInnovationDataManagement(int innovationDataManagement) {
		this.innovationDataManagement = innovationDataManagement;
	}



	public int getCyberSecurity() {
		return cyberSecurity;
	}



	public void setCyberSecurity(int cyberSecurity) {
		this.cyberSecurity = cyberSecurity;
	}



	public int getCollectiveIntelligence() {
		return collectiveIntelligence;
	}



	public void setCollectiveIntelligence(int collectiveIntelligence) {
		this.collectiveIntelligence = collectiveIntelligence;
	}



	public int getStrategyInnovation() {
		return strategyInnovation;
	}



	public void setStrategyInnovation(int strategyInnovation) {
		this.strategyInnovation = strategyInnovation;
	}

	
	public int getInternetOfThings() {
		return internetOfThings;
	}



	public void setInternetOfThings(int internetOfThings) {
		this.internetOfThings = internetOfThings;
	}




	public int getFrench() {
		return french;
	}



	public void setFrench(int french) {
		this.french = french;
	}



	@Override
	public String toString() {
		return "Semester3 [id=" + id + ",innovationSoftwareMethods=" + innovationSoftwareMethods
				+ ", innovationDataManagement=" + innovationDataManagement+ ", cyberSecurity=" + cyberSecurity
				+ ", collectiveIntelligence=" + collectiveIntelligence + ", strategyInnovation=" + strategyInnovation
				+ ", french=" + french + "]";
	}
	
	
	
	
	
	
}
