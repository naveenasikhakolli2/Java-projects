/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.client.sms.controller;

/**
 *
 * @author Balaji
 */
import java.util.Arrays;
import java.util.Base64;
import java.util.List;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.client.sms.entity.Semester1;
import com.client.sms.entity.Semester2;
import com.client.sms.entity.Semester3;
import com.client.sms.entity.Semester4;
import com.client.sms.entity.Student;

@Controller 
@RequestMapping("/student")
public class StudentController {
    public StudentController() {

	}
	

@GetMapping("/liststudent")
	public String listEmployees(Model theModel) {
		
		RestTemplate restTemplate = new RestTemplate();
    	String plainCreds = "john:test123";
    	byte[] plainCredsBytes = plainCreds.getBytes();
    	byte[] base64CredsBytes = Base64.getEncoder().encode(plainCredsBytes);
    	String base64Creds = new String(base64CredsBytes);
    	HttpHeaders headers = new HttpHeaders();
    	headers.add("Authorization", "Basic " + base64Creds);
    	String fooResourceUrl = "http://localhost:8080/api/students";
    	
    	HttpEntity<String> request = new HttpEntity<String>(headers);
    	ResponseEntity<Student[]> response = restTemplate.exchange(fooResourceUrl, HttpMethod.GET, request, Student[].class);
    	Student[] foo = response.getBody();
    	
    	List<Student> theStudent = Arrays.asList(foo);
    	theModel.addAttribute("Student", theStudent);
       
         
		
		return "list-student";
	}

	@GetMapping("/showFormForAdd")
	public String showFormForAdd(Model theModel) {
		
		// create model attribute to bind form data
		Student theStudent = new Student();
		Semester1 theSemester1 = new Semester1();
		Semester2 theSemester2 = new Semester2();
		Semester3 theSemester3 = new Semester3();
		Semester4 theSemester4 = new Semester4();
		
		theModel.addAttribute("student", theStudent);
		theModel.addAttribute("semester1", theSemester1);
		theModel.addAttribute("semester2", theSemester2);
		theModel.addAttribute("semester3", theSemester3);
		theModel.addAttribute("semester4", theSemester4);

		
		
		return "student-form";
	}
	
	@PostMapping("/save")
	public String saveEmployee(@ModelAttribute("student") Student theStudent,@ModelAttribute("semester1") Semester1 theSemester1,@ModelAttribute("semester2") Semester2 theSemester2,@ModelAttribute("semester3") Semester3 theSemester3,@ModelAttribute("semester4") Semester4 theSemester4) {
		
		
		
		theStudent.setSemester1(theSemester1);
		theStudent.setSemester2(theSemester2);
		theStudent.setSemester3(theSemester3);
		theStudent.setSemester4(theSemester4);
		
		Student newStudent = theStudent;

		
		RestTemplate restTemplate = new RestTemplate();
    	String plainCreds = "john:test123";
    	byte[] plainCredsBytes = plainCreds.getBytes();
    	byte[] base64CredsBytes = Base64.getEncoder().encode(plainCredsBytes);
    	String base64Creds = new String(base64CredsBytes);
    	HttpHeaders headers = new HttpHeaders();
    	headers.add("Authorization", "Basic " + base64Creds);
    	String fooResourceUrl = "http://localhost:8080/api/students";
    	headers.setContentType(MediaType.APPLICATION_JSON);
    	HttpEntity<?> httpEntity = new HttpEntity<Object>(newStudent,headers);
    	ResponseEntity<Student> response = restTemplate.exchange(fooResourceUrl, HttpMethod.POST,httpEntity, Student.class);

		return "redirect:/semester1/list";
	}	        
}



