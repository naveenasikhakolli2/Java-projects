/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.client.sms.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;





@JsonIgnoreProperties(ignoreUnknown = true)
public class Student {
    

	private int id;
	private String firstName;
	private String lastName;
	private String email;
	private Semester1 semester1;
	private Semester2 semester2;
	private Semester3 semester3;
	private Semester4 semester4;
	
	
	
	public Student() {
		
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	
	public Semester1 getSemester1() {
		return semester1;
	}
	
	
	public void setSemester1(Semester1 semester1) {
		this.semester1 = semester1;
	}
	
	
	public Semester2 getSemester2() {
		return semester2;
	}
	public void setSemester2(Semester2 semester2) {
		this.semester2 = semester2;
	}
	public Semester3 getSemester3() {
		return semester3;
	}
	public void setSemester3(Semester3 semester3) {
		this.semester3 = semester3;
	}
	public Semester4 getSemester4() {
		return semester4;
	}
	public void setSemester4(Semester4 semester4) {
		this.semester4 = semester4;
	}
    
    
    
}
