/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.client.sms.entity;

/**
 *
 * @author Galaxy
 */
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Semester2 {


	private int id;
	private int businessProcessModelling;
	private int computationalIntelligence;
	private int webServices;
	private int marketingInnovation;
	private int researchWorkshop;
	private int french; 
	  
	 

	public Semester2() {
		
	}

	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public int getBusinessProcessModelling() {
		return businessProcessModelling;
	}



	public void setBusinessProcessModelling(int businessProcessModelling) {
		this.businessProcessModelling = businessProcessModelling;
	}



	public int getComputationalIntelligence() {
		return computationalIntelligence;
	}



	public void setComputationalIntelligence(int computationalIntelligence) {
		this.computationalIntelligence = computationalIntelligence;
	}



	public int getWebServices() {
		return webServices;
	}



	public void setWebServices(int webServices) {
		this.webServices = webServices;
	}



	public int getMarketingInnovation() {
		return marketingInnovation;
	}



	public void setMarketingInnovation(int marketingInnovation) {
		this.marketingInnovation = marketingInnovation;
	}



	public int getResearchWorkshop() {
		return researchWorkshop;
	}



	public void setResearchWorkshop(int researchWorkshop) {
		this.researchWorkshop = researchWorkshop;
	}



	public int getFrench() {
		return french;
	}



	public void setFrench(int french) {
		this.french = french;
	}



	@Override
	public String toString() {
		return "Semester2 [id=" + id + ", businessProcessModelling=" + businessProcessModelling
				+ ", computationalIntelligence=" + computationalIntelligence + ", webServices=" + webServices
				+ ", marketingInnovation=" + marketingInnovation + ", researchWorkshop=" + researchWorkshop
				+ ", french=" + french + "]";
	}
	
	
	
	
	
	
}
