/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.client.sms.entity;

/**
 *
 * @author Balaji
 *
/**
 *
 * @author Galaxy
 */
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Semester4 {


	private int id;
	private int internship;
	 

	public Semester4() {
		
	}

	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public int getInternship() {
		return internship;
	}



	public void setInternship(int internship) {
		this.internship = internship;
	}



	
	

        @Override
	public String toString() {
		return "Semester4 [id=" + id + ",internship=" + internship
				+ ", ]";
	}
	
	
	
	
	
	
}
