package io.swagger.service;

import io.swagger.model.Exercise;
//import io.swagger.model.ExerciseHistory;
import io.swagger.model.Session;

import java.util.List;
import java.util.Map;

public interface ExerciseHistoryService {

    //List<ExerciseHistory> getListExerciseHistoryByUserId(String userId);
    //List<Session> getListSessionsByUserId(String userId);
    //List<Integer> getListPointOfSessionByUserId(String userId);
    //Map<String,Integer> getMapCalorieOfSessionByUserId(String userId);
}
