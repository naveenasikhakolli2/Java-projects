package io.swagger.service;

import io.swagger.model.Report;

public interface ReportService {
    Integer customerSendReport(Report report);
}
